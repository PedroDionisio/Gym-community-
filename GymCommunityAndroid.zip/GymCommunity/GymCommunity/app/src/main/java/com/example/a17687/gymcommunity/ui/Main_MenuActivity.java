package com.example.a17687.gymcommunity.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.User;
import com.example.a17687.gymcommunity.remote.SessionManager;

import java.text.DateFormat;
import java.util.Date;

public class Main_MenuActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private User user;


    public static void startActivity(Context context) {
        context.startActivity(new Intent(context, LoginActivity.class));
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:

                    return true;
                case R.id.navigation_aulas:
                    Intent Aulas = new Intent(Main_MenuActivity.this,AulasActivity.class);
                    startActivity(Aulas);
                    return true;
                case R.id.navigation_nos:

                    Intent feed = new Intent(Main_MenuActivity.this,FeedActivity.class);
                    startActivity(feed);
                    return true;


            }
            return false;





        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__menu);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        TextView dataatual = (TextView) findViewById(R.id.dataatual);
        String currentDateTimeString = DateFormat.getDateInstance().format(new Date());
        dataatual.setText(currentDateTimeString);






       /* this.user = SessionManager.load(this);

        if (this.user == null) {
            MainActivity.startActivity(this);
            finish();
        }*/
    }


    public void LogOut(View view) {


        SessionManager.delete(this);
        LoginActivity.startActivity(this);
        finish();
    }
}
