package com.example.a17687.gymcommunity.ui;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.Login;
import com.example.a17687.gymcommunity.model.LoginResponse;
import com.example.a17687.gymcommunity.model.Registo;
import com.example.a17687.gymcommunity.model.User;
import com.example.a17687.gymcommunity.remote.AuthService;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;
import com.example.a17687.gymcommunity.remote.SessionManager;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.widget.Toast.LENGTH_SHORT;

public class RegistoActivity extends AppCompatActivity {


    private EditText editTextNome;
    private EditText editTextMail;
    private EditText editTextPassword;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo);

        this.editTextNome = findViewById(R.id.editTextNome);
        this.editTextMail = findViewById(R.id.editTextMail);
        this.editTextPassword = findViewById(R.id.editTextPassword);


    }


    public void cancelar(View view) {
        finish();
    }

    public void voltar(View view) {
        finish();
    }

    public void registo(View view) {


        String nome = this.editTextNome.getText().toString();
        String email = this.editTextMail.getText().toString();
        String password = this.editTextPassword.getText().toString();


       /* if(TextUtils.isEmpty(nome) && (TextUtils.isEmpty(password)&& (TextUtils.isEmpty(email)))){

            Toast.makeText(RegistoActivity.this, "Introduza dados!", LENGTH_SHORT).show();

        }*/




        Registo registo = new Registo(nome, email, password);
        AuthService authService = RemoteDataSource.getAuthService();
        authService.registo(registo).enqueue(new Callback<Registo>() {





            @Override
            public void onResponse(Call<Registo> call, Response<Registo> response) {


                if (response.isSuccessful()) {



                    Toast.makeText(RegistoActivity.this, "Registado com sucesso! ", Toast.LENGTH_SHORT).show();
                    editTextPassword.setText("");
                    editTextMail.setText("");
                    editTextNome.setText("");

                    } else{

                    Toast.makeText(RegistoActivity.this, "Erro ao registar!", LENGTH_SHORT).show();


                }


            }

            @Override
            public void onFailure(Call<Registo> call, Throwable t) {
                System.out.println(t.getMessage());
            }

        });

    }

}
