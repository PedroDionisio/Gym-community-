package com.example.a17687.gymcommunity.ui;

import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.AulasAdapter;
import com.example.a17687.gymcommunity.remote.AuthService;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;

import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

@RequiresApi(api = Build.VERSION_CODES.N)
public class DetailsActivity extends AppCompatActivity {


    public static final String EXTRA_POSITION = "position";
    private ImageView imageView;
    private TextView textViewNome;
    private TextView textViewData;
    private TextView textViewVagas;
    private Aulas aula;
    private static final SimpleDateFormat todaySimpleDateFormat = new SimpleDateFormat("hh:mm:ss");
    private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy\nhh:mm:ss");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        this.imageView = findViewById(R.id.imageView3);
        this.textViewNome = findViewById(R.id.textViewNome);
        this.textViewData = findViewById(R.id.textViewData);
        this.textViewVagas = findViewById(R.id.textViewVagas);


        Intent intent = getIntent();


        Bundle extras = intent.getExtras();


        if (extras != null) {

            long id = extras.getLong(EXTRA_POSITION);

            AuthService remoteDataSource = RemoteDataSource.getAuthService();
            Call<Aulas> call = remoteDataSource.getAulaById(id);
            call.enqueue(new Callback<Aulas>() {

                @Override

                public void onResponse(Call<Aulas> call, Response<Aulas> response) {

                    if (response.isSuccessful()) {
                        DetailsActivity.this.aula = response.body();

                        String logoUrl = DetailsActivity.this.aula.getUrl();
                        Glide.with(DetailsActivity.this).asBitmap().load(logoUrl).into(imageView);

                        textViewNome.setText(DetailsActivity.this.aula.getNome_aula());
                        textViewVagas.setText(DetailsActivity.this.aula.getNumero_vagas());

                        textViewData.setText(getFormatedDate(DetailsActivity.this.aula.getData_aula()));
                    } else {
                        System.out.println(response.errorBody().toString());
                    }

                }

                @Override
                public void onFailure(Call<Aulas> call, Throwable t) {
                    System.out.println(t.getMessage());
                }
            });

        } else {

        }


    }


    public void voltar(View view) {
        finish();
    }

    public void inscrever(View view) {

    }

    public void cancelar(View view) {

        finish();
    }

    public String getFormatedDate(long miliseconds) {
        if (DateUtils.isToday(miliseconds)) {
            return todaySimpleDateFormat.format(new Date(miliseconds));
        } else {
            return simpleDateFormat.format(new Date(miliseconds));
        }
    }

}
