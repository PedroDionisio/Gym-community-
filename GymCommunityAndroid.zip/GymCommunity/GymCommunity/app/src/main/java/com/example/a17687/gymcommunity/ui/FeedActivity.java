package com.example.a17687.gymcommunity.ui;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.AulasAdapter;
import com.example.a17687.gymcommunity.model.Feed;
import com.example.a17687.gymcommunity.model.FeedAdapter;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FeedActivity extends AppCompatActivity {

    private FeedAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed);


        this.adapter = new FeedAdapter(this);
        ListView listView = findViewById(R.id.listViewFeed);
        listView.setAdapter(this.adapter);


        Call<List<Feed>> call = RemoteDataSource.getAuthService().getFeed();

        call.enqueue(new Callback<List<Feed>>() {
            @Override
            public void onResponse(Call<List<Feed>> call, Response<List<Feed>> response) {
                if (response.isSuccessful()) {
                    List<Feed> feedList = response.body();
                    adapter.refreshList(feedList);
                }
            }

            @Override
            public void onFailure(Call<List<Feed>> call, Throwable t) {


            }
        });
    }






    public void novoFeed(View view) {

        switch (view.getId()) {
            case R.id.fedd2:
                openDialog();
        }
    }




    private void openDialog(){


        Drawable drawable = getResources().getDrawable(R.mipmap.ic_launcher);
        View subView = getLayoutInflater().inflate(R.layout.feed_layout, null);


        final AlertDialog.Builder builder = new AlertDialog.Builder(this);


        builder.setView(subView);


        //Build the AlertDialog.
        AlertDialog alertDialog = builder.create();

        builder.setPositiveButton("Enviar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //This will close the Dialog
            }
        });

        builder.show();
    }

    public void voltar(View view) {
        finish();
    }




}
