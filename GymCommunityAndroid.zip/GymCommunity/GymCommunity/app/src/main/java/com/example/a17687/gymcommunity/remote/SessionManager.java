package com.example.a17687.gymcommunity.remote;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.a17687.gymcommunity.model.User;

public class SessionManager {

    public static final String PREFERENCES_NAME = "SessionPreferences";

    private static final String KEY_ID = "id";


    public static void saveSession(Context context, int cod_user){

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(KEY_ID, cod_user);

        editor.apply();
    }


    public static void delete(Context context){

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.remove(KEY_ID);

        editor.apply();

    }


    public static boolean isSessionActive(Context context){

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);

        return sharedPreferences.contains(KEY_ID);
    }


    public static int load (Context context){

        if(!isSessionActive(context)) return 0;

        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getInt(KEY_ID, 0);

    }


}