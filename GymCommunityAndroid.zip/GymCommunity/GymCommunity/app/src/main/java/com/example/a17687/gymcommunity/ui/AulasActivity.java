package com.example.a17687.gymcommunity.ui;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;


import com.example.a17687.gymcommunity.R;

import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.AulasAdapter;
import com.example.a17687.gymcommunity.remote.AuthService;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;
import com.example.a17687.gymcommunity.remote.SessionManager;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AulasActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private CheckBox  checkBox4;
    private CheckBox mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private AulasAdapter adapter;

    private TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aulas);


        this.adapter = new AulasAdapter(this);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(this.adapter);
        checkBox4 = findViewById(R.id.checkBox4);
        textView3 = findViewById(R.id.textView3);






     listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
         @SuppressLint("NewApi")
         @Override
         public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
             //DetailsActivity.startActivity(AulasActivity.this, id);
             if (checkBox4.isChecked())
             {




             }else {
                 Intent intent = new Intent(AulasActivity.this, DetailsActivity.class);
                 // Adicionar ao Intent a posição da lista que foi clicada

                 intent.putExtra(DetailsActivity.EXTRA_POSITION, id);
                 startActivity(intent);
             }



         }
     });





       Call<List<Aulas>> call = RemoteDataSource.getAuthService().getRandom();

        call.enqueue(new Callback<List<Aulas>>() {
            @Override
            public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                if (response.isSuccessful()) {
                    List<Aulas> aulasList = response.body();
                    adapter.refreshList(aulasList);
                }
            }

            @Override
            public void onFailure(Call<List<Aulas>> call, Throwable t) {

            }
        });

        //listView.setOnItemClickListener(itemClicked(View);
        mDisplayDate = (CheckBox) findViewById(R.id.checkBox2);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        AulasActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
                AuthService remoteDataSource = RemoteDataSource.getAuthService();


            }
        });


        mDateSetListener = new DatePickerDialog.OnDateSetListener() {


            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDisplayDate.setText(date);
            }
        };


    }


    public void voltar(View view) {
        finish();
    }

    public void itemClicked(View v) {
        if (((CheckBox) v).isChecked()) {

            textView3.setText("Todas as Aulas");



            Call<List<Aulas>> call = RemoteDataSource.getAuthService().getAulas();

            call.enqueue(new Callback<List<Aulas>>() {
                @Override
                public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                    if (response.isSuccessful()) {
                        List<Aulas> aulasList = response.body();
                        adapter.refreshList(aulasList);

                    }
                }

                @Override
                public void onFailure(Call<List<Aulas>> call, Throwable t) {


                }
            });
        }else {

            textView3.setText("Sugestão aulas para si ");

            Call<List<Aulas>> call = RemoteDataSource.getAuthService().getRandom();

            call.enqueue(new Callback<List<Aulas>>() {
                @Override
                public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                    if (response.isSuccessful()) {
                        List<Aulas> aulasList = response.body();
                        adapter.refreshList(aulasList);
                    }
                }

                @Override
                public void onFailure(Call<List<Aulas>> call, Throwable t) {

                }
            });


        }

    }


    public void minhas_aulas(View v) {

        if (((CheckBox) v).isChecked()) {

            textView3.setText("Minhas Aulas");




            Call<List<Aulas>> call = RemoteDataSource.getAuthService().getMinhasAulas(SessionManager.load(this));

            call.enqueue(new Callback<List<Aulas>>() {
                @Override
                public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                    if (response.isSuccessful()) {
                        List<Aulas> AulasList = response.body();
                        adapter.refreshList(AulasList);
                    }
                }

                @Override
                public void onFailure(Call<List<Aulas>> call, Throwable t) {


                }
            });


        }else {
            textView3.setText("Sugestão aulas para si ");

            Call<List<Aulas>> call = RemoteDataSource.getAuthService().getRandom();

            call.enqueue(new Callback<List<Aulas>>() {
                @Override
                public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                    if (response.isSuccessful()) {
                        List<Aulas> aulasList = response.body();
                        adapter.refreshList(aulasList);
                    }
                }

                @Override
                public void onFailure(Call<List<Aulas>> call, Throwable t) {

                }
            });
    }
}}



