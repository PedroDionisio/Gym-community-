package com.example.a17687.gymcommunity.model;

public class Registo {

    private String nome_utilizador;
    private String email_utilizador;
    private String password;


    public Registo(String nome_utilizador, String email_utilizador, String password) {
        this.nome_utilizador = nome_utilizador;
        this.email_utilizador = email_utilizador;
        this.password = password;
    }

    public String getNome_uilizador() {
        return nome_utilizador;
    }

    public void setNome_uilizador(String nome_uilizador) {
        this.nome_utilizador = nome_uilizador;
    }

    public String getEmail_utilizador() {
        return email_utilizador;
    }

    public void setEmail_utilizador(String email_utilizador) {
        this.email_utilizador = email_utilizador;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
