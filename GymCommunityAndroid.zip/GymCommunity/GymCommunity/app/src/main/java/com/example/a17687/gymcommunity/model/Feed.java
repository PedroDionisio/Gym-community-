package com.example.a17687.gymcommunity.model;

public class Feed {
    private long id_feed;
    private  long cod_utilizador;
    private String text;


    public Feed(long id_feed, long cod_utilizador, String text) {
        this.id_feed = id_feed;
        this.cod_utilizador = cod_utilizador;
        this.text = text;
    }


    public long getId_feed() {
        return id_feed;
    }

    public void setId_feed(long id_feed) {
        this.id_feed = id_feed;
    }

    public long getCod_utilizador() {
        return cod_utilizador;
    }

    public void setCod_utilizador(long cod_utilizador) {
        this.cod_utilizador = cod_utilizador;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
