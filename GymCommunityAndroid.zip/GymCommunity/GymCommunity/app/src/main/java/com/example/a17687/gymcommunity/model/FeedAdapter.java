package com.example.a17687.gymcommunity.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.a17687.gymcommunity.R;

import java.util.ArrayList;
import java.util.List;

public class FeedAdapter extends BaseAdapter {

    private List<Feed> feedList;
    private Context context;


    public FeedAdapter(Context context){

        this.context = context;
        this.feedList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return this.feedList.size();
    }

    @Override
    public Feed getItem(int position) {
        return this.feedList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).getId_feed();
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        if(convertView == null){

            convertView = LayoutInflater.from(this.context).inflate(R.layout.feed_row, parent, false);

            Feed feed= getItem(i);
            TextView textViewText = convertView.findViewById(R.id.textViewText);
            textViewText.setText(feed.getText());

        }
        return convertView;
    }



    public void refreshList(List<Feed> newList) {
        this.feedList = newList;
        notifyDataSetChanged();
    }
}
