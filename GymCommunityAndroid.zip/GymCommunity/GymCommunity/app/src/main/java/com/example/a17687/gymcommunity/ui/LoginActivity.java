package com.example.a17687.gymcommunity.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Login;
import com.example.a17687.gymcommunity.model.LoginResponse;
import com.example.a17687.gymcommunity.model.User;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;
import com.example.a17687.gymcommunity.remote.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.widget.Toast.LENGTH_SHORT;

public class LoginActivity extends AppCompatActivity {


    public static void startActivity(Context context) {
        context.startActivity(new Intent(context, LoginActivity.class));
    }

    private EditText editTextEmail;
    private EditText editTextPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        this.editTextEmail = findViewById(R.id.editTextEmail);
        this.editTextPassword = findViewById(R.id.editTextPassword);




    }

    public void registo(View view) {
        Intent intent = new Intent(this, RegistoActivity.class);
        startActivity(intent);
    }


    public void loginUser(View view) {

        String mail = this.editTextEmail.getText().toString();
        String password = this.editTextPassword.getText().toString();


        if(TextUtils.isEmpty(mail) && (TextUtils.isEmpty(password))){

            Toast.makeText(LoginActivity.this, "Introduza os dados de acesso!", LENGTH_SHORT).show();

        }


        RemoteDataSource.getAuthService().login(new Login(mail, password)).enqueue(new Callback<LoginResponse>() {



            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {



                if(response.isSuccessful() && ! response.body().getEmail_utilizador().equals("Not found")){
                    SessionManager.saveSession(LoginActivity.this,response.body().getCod_utilizador());
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);

                } else{
                    Toast.makeText(LoginActivity.this, "Erro nos dados de acesso!", LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

                System.out.println(t.getMessage());

            }
        });





    }


    public void session(View view) {
        if (((Switch) view).isChecked()) {



        }
    }
}






