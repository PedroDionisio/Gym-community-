package com.example.a17687.gymcommunity.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;

import com.example.a17687.gymcommunity.R;

public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private int mProgressStatus = 0;
    private Handler handler = new Handler();

    public static void startActivity(Context context) {
        context.startActivity(new Intent(context, MainActivity.class));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        progressBar = (ProgressBar) findViewById(R.id.bar);

        Drawable progressDrawable = progressBar.getProgressDrawable().mutate();
        progressDrawable.setColorFilter(Color.BLACK, android.graphics.PorterDuff.Mode.SRC_IN);
        progressBar.setProgressDrawable(progressDrawable);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(mProgressStatus < 100){

                    mProgressStatus++;
                    SystemClock.sleep(50);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(mProgressStatus);
                        }
                    });

                }

                handler.post(new Runnable() {
                    @Override
                    public void run() {

                        Intent intent = new Intent(MainActivity.this, Main_MenuActivity.class);
                        startActivity(intent);

                    }
                });
            }
        }).start();


    }
}
