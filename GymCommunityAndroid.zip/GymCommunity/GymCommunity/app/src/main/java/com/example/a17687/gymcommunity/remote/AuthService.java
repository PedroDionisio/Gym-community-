package com.example.a17687.gymcommunity.remote;

import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.Feed;
import com.example.a17687.gymcommunity.model.Login;
import com.example.a17687.gymcommunity.model.LoginResponse;
import com.example.a17687.gymcommunity.model.Registo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface AuthService {

    @POST("user/login.php")
    Call<LoginResponse> login(@Body Login login);

    @GET("user/aulas.php")
    Call<List<Aulas>> getAulas();

    @GET("user/aulas.php")
    Call<Aulas> getAulaById(@Query("aulas_id") long aula_id);


    @GET("user/random.php")
    Call<List<Aulas>> getRandom();

    @GET("user/query_feed.php")
    Call<List<Feed>> getFeed();


    @GET("user/query_minhasaulas.php")
    Call<List<Aulas>> getMinhasAulas(@Query("cod_utilizador") long cod_utilizador);

    @POST("user/registo.php")
    Call<Registo> registo(@Body Registo Registo);
}
