package com.example.a17687.gymcommunity.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.a17687.gymcommunity.R;


import java.util.ArrayList;
import java.util.List;

public class AulasAdapter extends BaseAdapter {

    private List<Aulas> aulasList;
    private Context context;


    public AulasAdapter(Context context){

        this.context = context;
        this.aulasList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return this.aulasList.size();
    }

    @Override
    public Aulas getItem(int position) {
        return this.aulasList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).getCod_aula();

    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {

        if(convertView == null){

            convertView = LayoutInflater.from(this.context).inflate(R.layout.listview_row, parent, false);

        }

        Aulas aulas = getItem(i);
        TextView textViewNome = convertView.findViewById(R.id.textViewNome);
        textViewNome.setText(aulas.getNome_aula());

       ImageView imageView = convertView.findViewById(R.id.imageViewAula);
        String logoUrl = aulas.getUrl();
        Glide.with(this.context).asBitmap().load(logoUrl).into(imageView);

        return convertView;

    }


    public void refreshList(List<Aulas> newList) {
        this.aulasList = newList;
        notifyDataSetChanged();
    }



}
