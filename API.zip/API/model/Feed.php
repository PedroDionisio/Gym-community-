<?php
/**
 * Created by PhpStorm.
 * User: Cesar
 * Date: 24/01/2019
 * Time: 00:10
 */

class Feed implements JsonSerializable
{


    public $id_feed,$cod_utilizador,$text;

    /**
     * Feed constructor.
     * @param $id_feed
     * @param $cod_utilizador
     * @param $text
     */
    public function __construct($id_feed, $cod_utilizador, $text)
    {
        $this->id_feed = $id_feed;
        $this->cod_utilizador = $cod_utilizador;
        $this->text = $text;
    }

    /**
     * @return mixed
     */
    public function getIdFeed()
    {
        return $this->id_feed;
    }

    /**
     * @return mixed
     */
    public function getCodUtilizador()
    {
        return $this->cod_utilizador;
    }

    /**
     * @return mixed
     */
    public function getText()
    {
        return $this->text;
    }





    public function jsonSerialize()
    {
        return [
            'id_feed' => $this->id_feed,
            'cod_utilizador' => $this->cod_utilizador,
            'text' => $this->text

        ];
    }

}