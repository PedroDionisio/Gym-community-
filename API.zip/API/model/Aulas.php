<?php
/**
 * Created by PhpStorm.
 * User: Pedro Dionisio
 * Date: 11/01/2019
 * Time: 13:05
 */

class aulas implements JsonSerializable
{
    public $cod_aula, $nome_aula, $numero_vagas, $data_aula;

    /**
     * aulas constructor.
     * @param $cod_aula
     * @param $nome_aula
     * @param $numero_vagas
     * @param $data_aula
     */
    public function __construct($cod_aula, $nome_aula, $numero_vagas, $data_aula)
    {
        $this->cod_aula = $cod_aula;
        $this->nome_aula = $nome_aula;
        $this->numero_vagas = $numero_vagas;
        $this->data_aula = $data_aula;
    }

    /**
     * @return mixed
     */
    public function getCodAula()
    {
        return $this->cod_aula;
    }

    /**
     * @return mixed
     */
    public function getNomeAula()
    {
        return $this->nome_aula;
    }

    /**
     * @return mixed
     */
    public function getNumeroVagas()
    {
        return $this->numero_vagas;
    }

    /**
     * @return mixed
     */
    public function getDataAula()
    {
        return $this->data_aula;
    }


    public function jsonSerialize()
    {
        return [
            'cod_aula' => $this->cod_aula,
            'nome_aula' => $this->nome_aula,
            'numero_vagas' => $this->numero_vagas,
            'data_aula' => $this->data_aula


        ];
    }


}