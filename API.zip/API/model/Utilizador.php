<?php
/**
 * Created by PhpStorm.
 * User: Pedro Dionisio
 * Date: 11/01/2019
 * Time: 13:06
 */

class utilizador implements JsonSerializable
{


    public $cod_utilizador, $nome_utilizador, $email_utilizador, $password, $token;

    /**
     * utilizador constructor.
     * @param $cod_utilizador
     * @param $nome_utilizador
     * @param $email_utilizador
     * @param $morada_utilizador
     * @param $idade_utilizador
     * @param $sexo_utilizador
     * @param $password
     * @param $professor
     */
    public function __construct($cod_utilizador, $nome_utilizador, $email_utilizador,  $password, $token  )
    {
        $this->cod_utilizador = $cod_utilizador;
        $this->nome_utilizador = $nome_utilizador;
        $this->email_utilizador = $email_utilizador;
        $this->password = $password;
        $this->token= $token;
    }

    /**
     * @return mixed
     */
    public function getCodUtilizador()
    {
        return $this->cod_utilizador;
    }

    /**
     * @return mixed
     */
    public function getNomeUtilizador()
    {
        return $this->nome_utilizador;
    }

    /**
     * @return mixed
     */
    public function getEmailUtilizador()
    {
        return $this->email_utilizador;
    }

    /**
     * @return mixed
     */

    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @return mixed
     */

    public function getToken()
    {
        return $this->token;
    }

    /**
     * @param mixed $cod_utilizador
     */
    public function setCodUtilizador($cod_utilizador)
    {
        $this->cod_utilizador = $cod_utilizador;
    }

    /**
     * @param mixed $nome_utilizador
     */
    public function setNomeUtilizador($nome_utilizador)
    {
        $this->nome_utilizador = $nome_utilizador;
    }

    /**
     * @param mixed $email_utilizador
     */
    public function setEmailUtilizador($email_utilizador)
    {
        $this->email_utilizador = $email_utilizador;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @param mixed $token
     */
    public function setToken($token)
    {
        $this->token = $token;
    }





    public function jsonSerialize()
    {

        return [

            'cod_utilizador' => $this->cod_utilizador,
            'nome_utilizador' => $this->nome_utilizador,
            'email_utilizador' => $this->email_utilizador,
            'password' => $this->password,
            'token' => $this->token
        ];
    }


}