<?php
/**
 * Created by PhpStorm.
 * User: Pedro Dionisio
 * Date: 11/01/2019
 * Time: 13:06
 */

class utilizador_aulas implements JsonSerializable
{

    public $cod_utilizador, $cod_aula;

    /**
     * utilizador_aulas constructor.
     * @param $cod_utilizador
     * @param $cod_aula
     */
    public function __construct($cod_utilizador, $cod_aula)
    {
        $this->cod_utilizador = $cod_utilizador;
        $this->cod_aula = $cod_aula;
    }

    /**
     * @return mixed
     */
    public function getCodUtilizador()
    {
        return $this->cod_utilizador;
    }

    /**
     * @return mixed
     */
    public function getCodAula()
    {
        return $this->cod_aula;
    }

    public function jsonSerialize()
    {
        return [
            'cod_utilizador' => $this->cod_utilizador,
            'cod_aula' => $this->cod_aula
        ];
    }

}