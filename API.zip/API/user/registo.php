<?php
include_once "../DBManager.php";

header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$input = json_decode(file_get_contents('php://input'));

if(!empty($input->nome_utilizador) && !empty($input->email_utilizador) &&  !empty($input->password)) {

    if($dbManager->searchUser($input->email_utilizador) == null){

        $utilizador = new utilizador(-1, $input->nome_utilizador,$input->email_utilizador,$input->password, "" );
        $newUtilizador = $dbManager->registerUser($utilizador);
        $dbManager->closeConnection();
        $data = array("action"=>"registo","result" => "sucesso");

        echo json_encode($data);

    }else{

        $failureData = new utilizador(-1, "", "Email já registado", "", "");

        echo json_encode($failureData);


    }

}
?>