<?php
include_once "../DBManager.php";

header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$input = json_decode(file_get_contents('php://input'));

if(!empty($input->nome_utilizador) && !empty($input->email_utilizador) &&  !empty($input->password)) {

    if($dbManager->searchUser($input->email_utilizador) == null){

        $utilizador = new utilizador(-1, $input->nome_utilizador,$input->email_utilizador,$input->password, "" );
        $newUtilizador = $dbManager->registerUser($utilizador);
        $dbManager->closeConnection();

        echo json_encode($newUtilizador);

    }else{

        $failureData = new utilizador(-1, "", "EMAIL JÁ REGISTADO", "", "");

        echo json_encode($failureData);


    }

}
?>