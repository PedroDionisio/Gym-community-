<?php
/**
 * Created by PhpStorm.
 * User: Cesar
 * Date: 22/01/2019
 * Time: 01:01
 */


include_once "../DBManager.php";


header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$aulas = $dbManager->getAllrandom();

$dbManager->closeConnection();

echo json_encode($aulas);
?>