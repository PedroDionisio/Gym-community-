<?php
include_once "../DBManager.php";


header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$aulas="";
if(isset($_GET['cod_utilizador'])){
    $cod_utilizador = $_GET['cod_utilizador'];
    $aulas = $dbManager->getminhasaulas($cod_utilizador);
}

$dbManager->closeConnection();

echo json_encode($aulas);