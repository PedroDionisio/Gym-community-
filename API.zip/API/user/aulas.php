<?php
/**
 * Created by PhpStorm.
 * User: Cesar
 * Date: 19/01/2019
 * Time: 15:51
 */
include_once "../DBManager.php";


header("Content-Type: application/json");

$dbManager = DBManager::getInstance();


if(isset($_GET['aulas_id'])){
    $id_aula = $_GET['aulas_id'];
    $aulas = $dbManager->getAllaulasById($id_aula);
}else{
    $aulas = $dbManager->getAllaulas();
}

$dbManager->closeConnection();

echo json_encode($aulas);