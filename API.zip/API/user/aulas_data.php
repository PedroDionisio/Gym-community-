<?php
/**
 * Created by PhpStorm.
 * User: Cesar
 * Date: 19/01/2019
 * Time: 17:43
 */


include_once "../DBManager.php";


header("Content-Type: application/json");


$rows = [];

if (!empty($_POST)) {
    $data_aula = $_POST['data_aula'];
    if ($data_aula != 0) {
        $conn = connDB();
        $result = query_data($conn, $data_aula);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc())
                array_push($rows, $row);
        }
    }
}

echo json_encode($rows);

?>