<?php
include_once "../DBManager.php";

header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

//$input = json_decode(file_get_contents('php://input'));

$aulas = [];
if(isset($_GET['cod_aula']) && isset($_GET['cod_utilizador'])){
    $cod_aula = $_GET['cod_aula'];
    $cod_utilizador = $_GET['cod_utilizador'];
    $aulas = $dbManager->registoAula($cod_aula, $cod_utilizador);
    var_dump($cod_aula, $cod_utilizador);
}



$dbManager->closeConnection();

echo json_encode($aulas);