


<?php


include_once "../DBManager.php";

header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$input = json_decode(file_get_contents('php://input'));

$utilizador = new utilizador(-1,"","","","");

if (!empty($input->email_utilizador) && !empty($input->password)){


    if($dbManager->searchUser($input->email_utilizador) != null ){

        $utilizador = $dbManager->loginUser($input->email_utilizador, $input->password);
        $dbManager->closeConnection();

        echo json_encode($utilizador);

    }else{

        $failureData = new utilizador(-1, "","Not found" , "", "");

        echo json_encode($failureData);

    }


}
?>