<?php
/**
 * Created by PhpStorm.
 * User: Ricardo
 * Date: 22/12/2018
 * Time: 14:59
 */

include_once "../DBManager.php";

header("Content-Type: application/json; charset=utf-8");

$failureData = ["request-type" => "register", "result" => "failure", "errorType" => "email already registered"];

$dbManager = DBManager::getInstance();

$input = json_decode(file_get_contents('php://input'));

if(!empty($input->nome_utilizador) && !empty($input->email_utilizador) && !empty($input->password)) {

    if($dbManager->searchEmail($input->email_utilizador)->email_utilizador == null){

        $utilizador = $dbManager->searchEmail($input->email_utilizador);

        $dbManager->closeConnection();

        echo json_encode($user);

    }else{

        echo json_encode($failureData);

    }


}

?>