<?php


include_once "../DBManager.php";

header("Content-Type: application/json");

$dbManager = DBManager::getInstance();

$feed = $dbManager->getAllfeed();

$dbManager->closeConnection();

echo json_encode($feed);
?>

