<?php
/**
 * Created by PhpStorm.
 * User: Pedro Dionisio
 * Date: 11/01/2019
 * Time: 13:00
 */


include_once "model/Utilizador.php";
include_once "model/Aulas.php";
include_once "model/Utilizador_aulas.php";

class DBManager
{

    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "gym";


    private $conn;




    public static function getInstance(){

        static $inst = null;
        if ($inst === null) {
            $inst = new DBManager();
        }
        return $inst;

    }

    private function __construct()
    {
        // Create connection
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);



        $this->conn->set_charset('utf8mb4');
    }






    public function loginUser($email_utilizador, $password) {
        $passwordHash = password_hash($password, PASSWORD_BCRYPT);
        /* create a prepared statement */
        $stmt = $this->conn->prepare("SELECT * FROM utilizador WHERE email_utilizador = ? AND password = ?");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $stmt->bind_param("ss", $email_utilizador, $password);

            /* execute query */
            $stmt->execute();

            // Extract result set and loop rows
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();
            $stmt->close();

            return new utilizador($data['cod_utilizador'], $data['nome_utilizador'], $data['email_utilizador'] , "" , $data['token']);
        }
    }




    public function registerUser(utilizador $utilizador){
        $passwordCrypt = password_hash($utilizador->getPassword(), PASSWORD_BCRYPT);
        $token = bin2hex(random_bytes(64));
        /* create a prepared statement */
        $stmt = $this->conn->prepare("INSERT INTO utilizador (nome_utilizador, email_utilizador, password, token) VALUES (?, ?, ?, ?)");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $name = $utilizador->getNomeUtilizador();
            $email = $utilizador->getEmailUtilizador();
            $password = $utilizador->getPassword();
            $stmt->bind_param("ssss", $name, $email, $password, $token);
            /* execute query */
            $stmt->execute();
            /* close statement */
            $stmt->close();

            $utilizador->setToken($token);

            return $utilizador;
        }
    }


    public function searchUser($email_utilizador) {

        $stmt = $this->conn->prepare("SELECT * FROM utilizador WHERE email_utilizador = ? ");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $stmt->bind_param("s", $email_utilizador);

            /* execute query */
            $stmt->execute();

            // Extract result set and loop rows
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();
            $stmt->close();

            //return new User($data['user_id'], $data['name'], $data['email'], $data['password'], $data['auth_token']);
            return $data['email_utilizador'];
        }

    }


    public function closeConnection()
    {
        $this->conn->close();
    }







}