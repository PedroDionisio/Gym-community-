<?php
/**
 * Created by PhpStorm.
 * User: Pedro Dionisio
 * Date: 11/01/2019
 * Time: 13:00
 */


include_once "model/Utilizador.php";
include_once "model/Aulas.php";
include_once "model/Utilizador_aulas.php";
include_once "model/Feed.php";

class DBManager
{

    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "gym";


    private $conn;




    public static function getInstance(){

        static $inst = null;
        if ($inst === null) {
            $inst = new DBManager();
        }
        return $inst;

    }

    private function __construct()
    {
        // Create connection
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);



        $this->conn->set_charset('utf8mb4');
    }






    public function loginUser($email_utilizador, $password) {
        $passwordHash = password_hash($password, PASSWORD_BCRYPT);
        /* create a prepared statement */
        $stmt = $this->conn->prepare("SELECT * FROM utilizador WHERE email_utilizador = ? AND password = ?");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $stmt->bind_param("ss", $email_utilizador, $password);

            /* execute query */
            $stmt->execute();

            // Extract result set and loop rows
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();
            $stmt->close();

            return new utilizador($data['cod_utilizador'], $data['nome_utilizador'], $data['email_utilizador'] , "" , $data['token']);
        }
    }




    public function registerUser(utilizador $utilizador){
        //$passwordCrypt = password_hash($utilizador->getPassword(), PASSWORD_BCRYPT);
        $token = bin2hex(random_bytes(64));
        /* create a prepared statement */
        $stmt = $this->conn->prepare("INSERT INTO utilizador (nome_utilizador, email_utilizador, password, token) VALUES (?, ?, ?, ?)");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $name = $utilizador->getNomeUtilizador();
            $email = $utilizador->getEmailUtilizador();
            $password = $utilizador->getPassword();
            $stmt->bind_param("ssss", $name, $email, $password, $token);
            /* execute query */
            $stmt->execute();
            /* close statement */
            $stmt->close();

            $utilizador->setToken($token);

            return $utilizador;
        }
    }


    public function searchUser($email_utilizador) {

        $stmt = $this->conn->prepare("SELECT * FROM utilizador WHERE email_utilizador = ? ");
        if (false===$stmt ) {
            die('prepare() failed: ' . htmlspecialchars($this->conn->error));
        } else {
            /* bind parameters for markers */
            $stmt->bind_param("s", $email_utilizador);

            /* execute query */
            $stmt->execute();

            // Extract result set and loop rows
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();
            $stmt->close();

            //return new User($data['user_id'], $data['name'], $data['email'], $data['password'], $data['auth_token']);
            return $data['email_utilizador'];
        }

    }





public function getAllrandom() {
    $aulas = [];
    $sql = "SELECT * FROM aulas ORDER BY RAND() LIMIT 3";
    $result = $this->conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $aulaa = new aulas($row["cod_aula"], mb_convert_encoding($row["nome_aula"],"UTF-8"), mb_convert_encoding($row["numero_vagas"],"UTF-8"), mb_convert_encoding($row["data_aula"],"UTF-8"), mb_convert_encoding($row["url"],"UTF-8"));
            array_push($aulas, $aulaa);
        }
    }
    return $aulas;
}


    public function getAllaulas() {
        $aulas = [];
        $sql = "SELECT * FROM aulas";
        $result = $this->conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $aula = new aulas($row["cod_aula"], mb_convert_encoding($row["nome_aula"],"UTF-8"), mb_convert_encoding($row["numero_vagas"],"UTF-8"), mb_convert_encoding($row["data_aula"],"UTF-8"), mb_convert_encoding($row["url"],"UTF-8"));
                array_push($aulas, $aula);
            }
        }
        return $aulas;
    }

    public function getAllaulasById($id_aula){
        $aula = "";
        $sql = "SELECT * FROM aulas WHERE cod_aula = '$id_aula'";
        $result = $this->conn->query($sql);
        if($result->num_rows > 0){
            while ($row = $result->fetch_assoc()) {
                $aula = new aulas($row["cod_aula"], mb_convert_encoding($row["nome_aula"], "UTF-8"), mb_convert_encoding($row["numero_vagas"], "UTF-8"), mb_convert_encoding($row["data_aula"], "UTF-8"), mb_convert_encoding($row["url"], "UTF-8"));
            }
        }
        return $aula;
    }





    function query_data($conn,$data_aula)
    {
        $sql = "SELECT * FROM aulas WHERE data_aula='$data_aula'";
        $result = $this->conn->query($sql);
        //endConnDB($conn);
        return $result;
    }


public function getminhasaulas($cod_utilizador){
        $aulas = [];
    $sql = "select * from aulas WHERE cod_aula in (SELECT cod_aula FROM `utilizador_aulas` where cod_utilizador = '$cod_utilizador')";
    $result = $this->conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $minhaaula = new aulas($row["cod_aula"], mb_convert_encoding($row["nome_aula"], "UTF-8"), mb_convert_encoding($row["numero_vagas"], "UTF-8"),
                mb_convert_encoding($row["data_aula"], "UTF-8"), mb_convert_encoding($row["url"], "UTF-8"));
            array_push($aulas, $minhaaula);
        }
    }
    return $aulas;

}


    public function getAllfeed() {
        $feeds = [];
        $sql = "SELECT * FROM feed";
        $result = $this->conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $feed = new feed($row["id_feed"], mb_convert_encoding($row["cod_utilizador"],"UTF-8"), mb_convert_encoding($row["text"],"UTF-8"));
                array_push($feeds, $feed);
            }
        }
        return $feeds;
    }

/*----------------------------------------------------------------------------*/
    public function registoAula($cod_utilizador, $cod_aula) {

        $sql = "INSERT INTO utilizador_aulas(cod_utilizador, cod_aula) VALUES ('$cod_utilizador','$cod_aula')";
        $result = $this->conn->query($sql);
        return $result;

    }





    public function closeConnection()
    {
        $this->conn->close();
    }



}