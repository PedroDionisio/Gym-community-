package com.example.a17687.gymcommunity.model;

public class Aulas {

    private long cod_aula;
    private String nome_aula;
    private String numero_vagas;
    private long data_aula;
    private String url;


    public Aulas(long cod_aula, String nome_aula, String numero_vagas, long data_aula, String url) {
        this.cod_aula = cod_aula;
        this.nome_aula = nome_aula;
        this.numero_vagas = numero_vagas;
        this.data_aula = data_aula;
       // this.url = url;
    }

    public long getCod_aula() {
        return cod_aula;
    }

    public void setCod_aula(long cod_aula) {
        this.cod_aula = cod_aula;
    }

    public  String getNome_aula() {
        return nome_aula;
    }

    public void setNome_aula(String nome_aula) {
        this.nome_aula = nome_aula;
    }

    public String getNumero_vagas() {
        return numero_vagas;
    }

    public void setNumero_vagas(String numero_vagas) {
        this.numero_vagas = numero_vagas;
    }

    public long getData_aula() {
        return data_aula;
    }

    public void setData_aula(long data_aula) {
        this.data_aula = data_aula;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
