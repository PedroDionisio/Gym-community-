package com.example.a17687.gymcommunity.remote;

import com.example.a17687.gymcommunity.model.Login;
import com.example.a17687.gymcommunity.model.LoginResponse;
import com.example.a17687.gymcommunity.model.Registo;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface AuthService {

    @POST("user/login.php")
    Call<LoginResponse> login(@Body Login login);


    @Headers({"Accept: application/json"})
    @POST("RegisterCliente.php")
    Call<Registo> registo(@Body Registo Registo);
}
