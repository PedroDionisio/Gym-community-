package com.example.a17687.gymcommunity.model;

public class LoginResponse {

    private int cod_utilizador;
    private String nome_utilizador;
    private String email_utilizador;
    private String password;
    private String token;


    public LoginResponse(int cod_utilizador, String nome_utilizador, String email_utilizador, String password, String token) {
        this.cod_utilizador = cod_utilizador;
        this.nome_utilizador = nome_utilizador;
        this.email_utilizador = email_utilizador;
        this.password = password;
        this.token = token;
    }

    public int getCod_utilizador() {
        return cod_utilizador;
    }

    public String getNome_utilizador() {
        return nome_utilizador;
    }

    public String getEmail_utilizador() {
        return email_utilizador;
    }

    public String getPassword() {
        return password;
    }

    public String getToken() {
        return token;
    }
}
