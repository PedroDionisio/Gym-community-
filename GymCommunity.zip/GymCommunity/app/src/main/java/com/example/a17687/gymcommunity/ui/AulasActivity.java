package com.example.a17687.gymcommunity.ui;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.Toast;


import com.example.a17687.gymcommunity.R;

import com.example.a17687.gymcommunity.model.Aulas;
import com.example.a17687.gymcommunity.model.AulasAdapter;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;

import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AulasActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private CheckBox mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private AulasAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aulas);


        this.adapter = new AulasAdapter(this);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(this.adapter);


        mDisplayDate = (CheckBox) findViewById(R.id.checkBox2);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        AulasActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });


        mDateSetListener = new DatePickerDialog.OnDateSetListener() {


            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDisplayDate.setText(date);
            }
        };


    }


    public void voltar(View view) {
        finish();
    }

   /* public void itemClicked(View v) {
        if (((CheckBox) v).isChecked()) {


            Call<List<Aulas>> call = RemoteDataSource.getAuthService().getAulas();

            call.enqueue(new Callback<List<Aulas>>() {
                @Override
                public void onResponse(Call<List<Aulas>> call, Response<List<Aulas>> response) {
                    if (response.isSuccessful()) {
                        List<Aulas> aulasList = response.body();
                        adapter.refreshList(aulasList);
                    }
                }

                @Override
                public void onFailure(Call<List<Aulas>> call, Throwable t) {

                }
            });
        }
    }*/


}
