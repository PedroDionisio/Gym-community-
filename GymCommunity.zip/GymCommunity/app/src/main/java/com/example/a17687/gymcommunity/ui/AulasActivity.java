package com.example.a17687.gymcommunity.ui;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.GridView;

import com.example.a17687.gymcommunity.model.GridViewAdapter;
import com.example.a17687.gymcommunity.R;

import java.util.Calendar;

public class AulasActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private CheckBox mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;

     GridView gridView;
     String[] values = {

             "Body Combat",
             "Body Pump",
             "jump",

     };

     int[] images = {

             R.drawable.logo,
             R.drawable.logo,
             R.drawable.logo,

     };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aulas);


        gridView = (GridView) findViewById(R.id.gridview);

        GridViewAdapter gridViewAdapter = new GridViewAdapter(this,values,images);
        gridView.setAdapter(gridViewAdapter);



        mDisplayDate = (CheckBox) findViewById(R.id.checkBox2);

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        AulasActivity.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });


        mDateSetListener = new DatePickerDialog.OnDateSetListener() {


            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDisplayDate.setText(date);
            }
        };
    }

    public void voltar(View view) {
        finish();
    }
}
