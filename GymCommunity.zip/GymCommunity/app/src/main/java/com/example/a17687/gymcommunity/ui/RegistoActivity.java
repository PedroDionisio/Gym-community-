package com.example.a17687.gymcommunity.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Registo;
import com.example.a17687.gymcommunity.remote.AuthService;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistoActivity extends AppCompatActivity {


    private EditText editTextNome;
    private EditText editTextEmail;
    private EditText editTextPassword;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registo);

        this.editTextNome = findViewById(R.id.editTextEmail);
        this.editTextEmail = findViewById(R.id.editTextEmail);
        this.editTextPassword = findViewById(R.id.editTextPassword);



    }


    public void cancelar(View view) {
        finish();
    }

    public void voltar(View view) {
        finish();
    }

    public void registo(View view) {


    String nome = this.editTextNome.getText().toString();
    String email = this.editTextEmail.getText().toString();
    String password = this.editTextPassword.getText().toString();





       Registo registo = new Registo(nome, email, password);
        AuthService authService = RemoteDataSource.getAuthService();
        authService.registo(registo).enqueue(new Callback<Registo>() {


            @Override
            public void onResponse(Call<Registo> call, Response<Registo> response) {
                if (response.isSuccessful()) {

                    Toast.makeText(RegistoActivity.this,
                            "Registado com sucesso!", Toast.LENGTH_LONG).show();
                    editTextEmail.setText("");
                    editTextNome.setText("");
                    editTextPassword.setText("");

                } else {
                    try {
                        Toast.makeText(RegistoActivity.this, response.errorBody().string(), Toast.LENGTH_LONG);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }


            }

            @Override
            public void onFailure(Call<Registo> call, Throwable t) {
                System.out.println(t.getMessage());
            }

        });

    }

}
