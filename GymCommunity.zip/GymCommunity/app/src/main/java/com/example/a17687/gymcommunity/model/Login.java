package com.example.a17687.gymcommunity.model;

public class Login {

    private String email_utilizador;
    private String password;


    public Login(String email_utilizador, String password) {
        this.email_utilizador = email_utilizador;
        this.password = password;
    }

    public String getEmail_utilizador() {
        return email_utilizador;
    }

    public String getPassword() {
        return password;
    }
}
