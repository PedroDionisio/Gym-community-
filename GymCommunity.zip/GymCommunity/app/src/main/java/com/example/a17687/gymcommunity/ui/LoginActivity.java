package com.example.a17687.gymcommunity.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.a17687.gymcommunity.R;
import com.example.a17687.gymcommunity.model.Login;
import com.example.a17687.gymcommunity.model.LoginResponse;
import com.example.a17687.gymcommunity.remote.RemoteDataSource;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.widget.Toast.LENGTH_SHORT;

public class LoginActivity extends AppCompatActivity {


    private EditText editTextEmail;
    private EditText editTextPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        this.editTextEmail = findViewById(R.id.editTextEmail);
        this.editTextPassword = findViewById(R.id.editTextPassword);
    }

    public void registo(View view) {
        Intent intent = new Intent(this, RegistoActivity.class);
        startActivity(intent);
    }


    public void loginUser(View view) {

        String mail = this.editTextEmail.getText().toString();
        String password = this.editTextPassword.getText().toString();


        if(TextUtils.isEmpty(mail) && (TextUtils.isEmpty(password))){

            Toast.makeText(LoginActivity.this, "Introduza os dados de acesso!", LENGTH_SHORT).show();

        }



        RemoteDataSource.getAuthService().login(new Login(mail, password)).enqueue(new Callback<LoginResponse>() {



            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {


                if(response.isSuccessful() && ! response.body().getEmail_utilizador().equals("Not found")){


                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);

                } else{
                    Toast.makeText(LoginActivity.this, "Erro nos dados de acesso!", LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

                System.out.println(t.getMessage());

            }
        });



    }
}
